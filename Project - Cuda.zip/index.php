<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Cuda - an awesome single page portfolio html template. It's very simple and easy to learn.">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cuda - an awesome single page portfolio html template</title>
        <!--Title Icon-->
    <link rel="shortcut icon" type="image/x-icon" href="resources/img/pen.png">
        <!--Google Fonts-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700&display=swap" rel="stylesheet">
        <!--Vendor Files-->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="vendors/css/normalize.css">
    <link rel="stylesheet" href="vendors/css/grid.css">
     <!--Resources files-->
    <link rel="stylesheet" href="resources/css/style.css">
    <link rel="stylesheet" href="resources/css/responsive.css">
        <!--Font Awesome-->
    <link rel="stylesheet" href="resources/css/all.min.css">
    <link rel="stylesheet" href="resources/css/fontawesome.min.css">
</head>
<body>
   
    <!--Header starts-->
    
    <header id="home">
        <nav>
            <div class="row">
                <a href="#home">
                    <img class="logo" src="resources/img/logo.png" alt="logo">
                </a>
                <ul class="main-nav">
                    <li class="active nav-item"><a href="#home">home</a></li>
                    <li class="nav-item"><a href="#service">service</a></li>
                    <li class="nav-item"><a href="#team">team</a></li>
                    <li class="nav-item"><a href="#skill">skill</a></li>
                    <li class="nav-item"><a href="#portfolio">portfolio</a></li>
                    <li class="nav-item"><a href="#testimonial">testimonial</a></li>
                    <li class="nav-item"><a href="#contact">contact</a></li>
                </ul>
                <div style="color: #fff;" class="mobile-menu">
                    <span onclick="openNav()">&#9776;</span>
                    <div id="myNav" class="overlay">
                        <a href="javascript:void(0)" onclick="closeNav()" class="closebtn">&times;</a>
                        <div class="overlay-content">
                            <a onclick="closeNav()" href="#home">home</a>
                            <a onclick="closeNav()" href="#service">service</a>
                            <a onclick="closeNav()" href="#team">team</a>
                            <a onclick="closeNav()" href="#skill">skill</a>
                            <a onclick="closeNav()" href="#portfolio">portfolio</a>
                            <a onclick="closeNav()" href="#testimonial">testimonial</a>
                            <a onclick="closeNav()" href="#contact">contact</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <div class="row">
            <div class="hero-text-box">
                <h1>Hi there! We are the new kids on the block and we build awesome websites and mobile apps.</h1>
                <a href="#" class="btn btn-hero">work with us!</a>
            </div>
        </div>
    </header>
    
    <!--Header ends-->
    
    <!--Services section starts-->
    
    <section class="services-section js--services-section" id="service">
        <div class="row">
            <h2>Services we provide</h2>
            <p class="little-description">We are working with both individuals and and businesses from all over the globe to create awesome websites and applications</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <img src="resources/img/flag.png" alt="flag" class="services-icon">
                <h3>Branding</h3>
                <p>businesses from all over the globe to create awesome websites and applications</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="resources/img/pen.png" alt="pen" class="services-icon">
                <h3>Design</h3>
                <p>businesses from all over the globe to create awesome websites and applications</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="resources/img/settings.png" alt="settings" class="services-icon">
                <h3>Development</h3>
                <p>businesses from all over the globe to create awesome websites and applications</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="resources/img/rocket.png" alt="rocket" class="services-icon">
                <h3>Rocket Science</h3>
                <p>businesses from all over the globe to create awesome websites and applications</p>
            </div>
        </div>
    </section>
    
    <!--Services section ends-->
    
    
    <!--Team section starts-->
    
    <section class="team-section" id="team">
        <div class="row">
            <h2>Meet our beautiful team</h2>
            <p class="little-description">
                We are a small team of designers and developers, who help brands with big ideas.
            </p>
        </div>
        <div class="row">
           
            <div class="col span_1_of_4 box">
                <img src="resources/img/MichaelScott.png" alt="Michael" class="team-member">
                <h3>Michael Scott</h3>
                <span class="role">Regional Manager / Scranton</span>
                <p>businesses from all over the globe to create awesome websites and applications</p>
                <div class="social-link">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            
            <div class="col span_1_of_4 box">
                <img src="resources/img/dwight.png" alt="Dwight" class="team-member">
                <h3>Dwight Schrute</h3>
                <span class="role">Asst. Regional Manager</span>
                <p>businesses from all over the globe to create awesome websites and applications</p>
                <div class="social-link">
                    <ul>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            
            <div class="col span_1_of_4 box">
                <img src="resources/img/jim-halpert.png" alt="Jimothy" class="team-member">
                <h3>Jim Halpert</h3>
                <span class="role">Sales Executive</span>
                <p>businesses from all over the globe to create awesome websites and applications</p>
                <div class="social-link">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            
            <div class="col span_1_of_4 box">
                <img src="resources/img/Angela_Martin.png" alt="Michael" class="team-member">
                <h3>Angela Martin</h3>
                <span class="role">Senior Accountant</span>
                <p>businesses from all over the globe to create awesome websites and applications</p>
                <div class="social-link">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
            
        </div>
    </section>
    
    <!--Team section ends-->
    
    
    <!--Skill section starts-->
    
    <section class="skill-section" id="skill">
        <div class="row">
            <h2>We got skills!</h2>
            <p class="little-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque at erat nec ipsum lacinia tristique in et leo. Sed tempus dui sollicitudin</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
                  <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                  <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                  <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
                </svg>
                <h3>Web Design</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
                  <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                  <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                  <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
                </svg>
                <h3>html / css</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress graphic-design" data-percentage="70" viewBox="0 0 80 80">
                  <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                  <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                  <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
                </svg>
                <h3>Graphic Design</h3>
            </div>
            <div class="col span_1_of_4 box">
                <svg class="radial-progress ui-ux" data-percentage="85" viewBox="0 0 80 80">
                  <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                  <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                  <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
                </svg>
                <h3>ui / ux</h3>
            </div>
        </div>
    </section>
    
    <!--Skill section ends-->
    
    
    <!--Portfolio section starts-->
    
    <section class="portfolio-section" id="portfolio">
        <div class="row">
            <h2>our portfolio</h2>
            <p class="litle-description">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque at erat nec ipsum lacinia tristique in et leo. Sed tempus dui sollicitudin.
            </p>
        </div>
        <div class="row">
            <div class="portfolio-filter">
                <button type="button" data-filter="all">All</button>
                <button type="button" data-filter=".web">Web</button>
                <button type="button" data-filter=".apps">Apps</button>
                <button type="button" data-filter=".icons">Icons</button>
            </div>
        </div>
        <div class="row container">
            <div class="col span_1_of_2 mix apps box">
                <img src="resources/img/monitor1.png" alt="monitor1" class="portfolio-image">
                <h4>Isometric perspective mock-up</h4>
            </div>
            <div class="col mix span_1_of_2 web apps box">
                <img src="resources/img/monitor2.png" alt="monitor2" class="portfolio-image">
                <h4>Isometric perspective mock-up</h4>
            </div>
            <div class="col span_1_of_2  mix icons box">
                <img src="resources/img/monitor3.png" alt="monitor3" class="portfolio-image">
                <h4>Isometric perspective mock-up</h4>
            </div>
            <div class="col span_1_of_2  mix icons web apps box">
                <img src="resources/img/monitor4.png" alt="monitor4" class="portfolio-image">
                <h4>Isometric perspective mock-up</h4>
            </div>
        </div>
        <div class="row">
            <a href="#" class="btn btn-load-more">Load more projects</a>
        </div>
    </section>
    
    <!--Portfolio section ends-->
    
    <!--Testimonial section starts-->
    
    <section class="testimonial" id="testimonial">
        <div class="row">
            <h2>what people say about us</h2>
            <p class="little-description">Our clients love us</p>
        </div>
        <div class="row">
            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="resources/img/MichaelScott.png" alt="Michael Scott">
                </div>
                <div class="client-review">
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque at erat nec ipsum lacinia tristique in et leo. Sed tempus dui sollicitudin."</p>
                    <h3>Michael Scott</h3>
                    <span class="role">Manager of DM</span>
                </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="resources/img/dwight.png" alt="Dwight">
                </div>
                <div class="client-review">
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque at erat nec ipsum lacinia tristique in et leo. Sed tempus dui sollicitudin."</p>
                    <h3>Dwight Schrute</h3>
                    <span class="role">Asst. to The Manager</span>
                </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="resources/img/jim-halpert.png" alt="Jim Halpert">
                </div>
                <div class="client-review">
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque at erat nec ipsum lacinia tristique in et leo. Sed tempus dui sollicitudin."</p>
                    <h3>Jim Halpert</h3>
                    <span class="role">Sales Executive</span>
                </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="resources/img/Angela_Martin.png" alt="Angela">
                </div>
                <div class="client-review">
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque at erat nec ipsum lacinia tristique in et leo. Sed tempus dui sollicitudin."</p>
                    <h3>Angela Martin</h3>
                    <span class="role">Senior Accountant</span>
                </div>
            </div>
        </div>
    </section>
    
    <!--Testimonial section ends-->
    
    
    <!--Contact section starts-->
    
    <section class="contact-section" id="contact">
        <div class="row">
            <h2>Get in touch</h2>
            <p class="little-description">
                1600 Pennsylvanya Ave NW, Washington DC 20500, United States of America. Tel: (202) 456-1111
            </p>
        </div>
        <div class="row">
            <form action="https://formspree.io/f/mvovjvvl" method="POST">
                <div class="row">
                    <div class="col span_1_of_2">
                        <input type="text" name="Name" placeholder="Your Name *" required>
                    </div>
                    <div class="col span_1_of_2">
                        <input type="email" name="Email" placeholder="Your Email *" required>
                    </div>
                </div>
                <div class="row">
                    <textarea name="Message" cols="30" rows="10" placeholder="Your Message *" required></textarea>
                </div>
                <div class="row">
                    <input type="submit" value="SEND MESSAGE" class="btn btn-submit">
                </div>
            </form>
        </div>
    </section>
    
    <!--Contact section ends-->
    
    
    <!--Footer starts-->
    
    <footer class="footer-section">
        <div class="row">
            <ul>
                <li><a href="#">facebook</a></li>
                <li><a href="#">twitter</a></li>
                <li><a href="#">google+</a></li>
                <li><a href="#">linkedin</a></li>
                <li><a href="#">behance</a></li>
                <li><a href="#">dribbble</a></li>
                <li><a href="#">github</a></li>
            </ul>
        </div>
    </footer>
    
    <!--Footer ends-->
    
    
    <!--JS Scripts-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="vendors/js/html5shiv.min.js"></script>
    <script src="vendors/js/respond.min.js"></script>
    <script src="vendors/js/jquery.waypoints.min.js"></script>
    <script src="vendors/js/mixitup.min.js"></script>
    <script src="resources/js/main.js"></script>
    <!--
    <script type="text/javascript">
        $('.main-nav .nav-item a').click(function(){
            $('.nav-item a').css("background-color","");
            $(this).css("background-color","red");
        });
    </script>
    -->
    
</body>
</html>